<?php
/*
 * Dynamic Server Image Status addon for LGSL
 * Copyright (C) 2012 SpiffyTek
 *
 * http://spiffytek.com/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 */
 
/* Custom */
switch($server['s']['game']){
	case "nucleardawn":
		switch($type){
			case "small":
				$txt_outline = true;
				$text_color0 = ImageColorAllocate($im, 255, 149, 56);
			break;
			case "normal":
				$txt_outline = true;
				$text_color0 = ImageColorAllocate($im, 255, 149, 56);
			break;
			case "sky":
				$name_type_vertical = true;
				$txt_outline = true;
				$text_color1 = ImageColorAllocate($im, 255, 149, 56);
			break;
		}
	break;
}
?>